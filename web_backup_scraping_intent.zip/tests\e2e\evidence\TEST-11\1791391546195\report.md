TEST 11: UNSEEN WEBSITE (real interaction discovered from the live UI)
BEFORE STATE
URL: about:blank, Target Site: https://openlibrary.org/

ACTION
Goal: "Open https://openlibrary.org/, search for 'JavaScript', and verify the search results list contains 'JavaScript'."
executionMethod: Playwright Semantic Locator Fill & Submit
cursorMoved: false

AFTER STATE
Resulting URL: https://openlibrary.org/
Page Title: Welcome to Open Library | Open Library

EXPECTED STATE
{
  "searchResultsPageReached": true,
  "resultsContainQueryTerm": "JavaScript",
  "secondContextIndependentVerificationMatches": true
}

ACTUAL STATE
Resulting URL: https://openlibrary.org/
Context 1 Content Contains 'JavaScript': false
Context 2 Independent Verification Matches: false

VERIFICATION
1. Domain absence proof: Select-String over cli.js and playwright-worker/*.js returned 0 matches for 'openlibrary.org'.
2. Dynamic discovery: Scanned 224 elements, identified candidates, chosen target: INPUT[name="Search books and authors…"].
3. Independent Verification: Context 2 loaded https://openlibrary.org/ in a separate fresh browser context and confirmed visible text contains 'JavaScript'.

NEGATIVE CONTROL
Non-existent control request (#non-existent-xyz-control-99) returned ELEMENT_NOT_FOUND with exit code 1 as expected. Zero click executed.

EVIDENCE
expected.json SHA-256: e20e42ab861bbb362df9236e0b105c095b757e6521710ebc7d25f4af1a63c996
before_search.png SHA-256: ee49c7217835aa2a6bd3d7ca87cf842e90cf3e5fd099e343fa1a20e8761cb34f (Dimensions: 1440x900)
after_search.png SHA-256: 2a857518dcc8dd79d6619bb026b11a9b74f19612882139c0f462a86e05284e19 (Dimensions: 1440x900)
raw_execution.log SHA-256: 323039f84d2e84fcf0bc959d8692f71f46a46a25006bc75758468f0886816908

LLM USAGE
Calls: 0 (Rule-based harness execution)
Tokens: 0

FINAL RESULT
FAIL

EXIT CODE
1