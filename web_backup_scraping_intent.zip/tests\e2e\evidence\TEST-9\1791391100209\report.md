TEST 9: REAL UPLOAD (server-side completion)
BEFORE STATE
Server Uploads Count: 0, Local Payload: 8 MB (8388608 bytes), Local SHA-256: 6272356954e960177b749a5ccc31cacdfc61a3f96507e17fb7222e0c8fe6ed12

ACTION
Goal: "Upload C:\Users\SURIYA~1\AppData\Local\Temp\test9_8mb_payload_1791391100209.bin and tell me when the server has fully processed it."
executionMethod: Playwright FileChooser via styled button click
cursorMoved: false

AFTER STATE
Server Receipt ID: rcpt_8627b532-564c-42ae-a018-004145e31722
Status: complete
Server Received Size: 8388608 bytes
Server Computed SHA-256: 6272356954e960177b749a5ccc31cacdfc61a3f96507e17fb7222e0c8fe6ed12

EXPECTED STATE
{
  "serverStatus": "complete",
  "receivedSizeEqual": 8388608,
  "sha256Match": "6272356954e960177b749a5ccc31cacdfc61a3f96507e17fb7222e0c8fe6ed12",
  "receiptIdPresent": true,
  "serverSavedFileHashMatch": true
}

ACTUAL STATE
Receipt ID: rcpt_8627b532-564c-42ae-a018-004145e31722
Server Status: complete
Size Equal: true (8388608 bytes)
SHA-256 Equal: true
Server Saved-File Hash Match: true

VERIFICATION
1. Independent harness GET /api/uploads confirmed status 'complete'.
2. Received byte size (8,388,608) strictly matched local payload size.
3. Server-side SHA-256 hash matched local payload hash (6272356954e960177b749a5ccc31cacdfc61a3f96507e17fb7222e0c8fe6ed12).
4. Saved file on server disk was independently hashed and matched payload SHA-256.
5. Server Receipt ID generated and verified: rcpt_8627b532-564c-42ae-a018-004145e31722.

NEGATIVE CONTROLS
(a) Server 413 Rejection: DOM input listed file (length 1) but status area showed rejection, test harness verified FAIL.
(b) Dropped Connection at 50%: Server socket aborted at 50% upload, zero completed uploads recorded, test harness verified FAIL.
(c) Corrupted Bytes Mode: Server saved corrupted bytes, SHA-256 mismatch detected, test harness verified FAIL.

EVIDENCE
expected.json SHA-256: 297b3a637b690bb754d8601bce23d994d3f8433f05532cfb46484d80aca030d2
before_upload.png SHA-256: f6ef02e5df5cab46c4c0a0876704bb30c40350ae0301f1a39e9296aa113110cf (Dimensions: 1280x800)
after_upload.png SHA-256: eee9a23b80c77a4730342bb913497bd611e8a46d83d846231e74ab5a2ab9fbe4 (Dimensions: 1280x800)
raw_execution.log SHA-256: f3f274dde789262ea666ccfc5f1913f5993867772db92823ecf9c3b2190b62c5

LLM USAGE
Calls: 0 (Rule-based harness execution)
Tokens: 0

FINAL RESULT
PASS

EXIT CODE
0