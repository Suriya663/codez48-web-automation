const admin = require('firebase-admin');

let isInitialized = false;
let db = null;

const initAdmin = () => {
    if (isInitialized) return true;
    try {
        const saVar = process.env.FIREBASE_SERVICE_ACCOUNT;
        if (!saVar) {
            if (admin.apps.length === 0) admin.initializeApp();
            db = admin.firestore();
            isInitialized = true;
            return true;
        }

        let serviceAccount = JSON.parse(saVar.trim());
        if (serviceAccount.private_key) {
            serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
        }

        if (admin.apps.length === 0) {
            admin.initializeApp({
                credential: admin.credential.cert(serviceAccount)
            });
        }
        db = admin.firestore();
        isInitialized = true;
        return true;
    } catch (e) {
        console.error('Firebase Admin Init Failure in preview-website:', e.message);
        return false;
    }
};

exports.handler = async (event, context) => {
    // 1. Extract ID from all possible sources (Resilience against environment variations)
    const q = event.queryStringParameters || {};
    let id = q.id || q.projectId;

    if (!id) {
        // Try path segments
        const pathMatch = event.path ? event.path.match(/\/preview\/([^\/]+)/) : null;
        if (pathMatch) {
            id = pathMatch[1];
        }
    }

    if (!id && event.rawUrl) {
        // Try raw URL
        const urlMatch = event.rawUrl.match(/\/preview\/([^\/\?#]+)/);
        if (urlMatch) {
            id = urlMatch[1];
        }
    }

    if (!id) {
        return {
            statusCode: 400,
            headers: { "Content-Type": "text/html" },
            body: `
                <html>
                    <body style="font-family: sans-serif; text-align: center; padding: 50px; color: #666;">
                        <h1 style="color: #ef4444;">Error: Missing project ID</h1>
                        <p>No project ID was detected in the request URL.</p>
                        <hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">
                        <p style="font-size: 0.8rem; color: #999;">Path Segment: ${event.path || 'N/A'}</p>
                        <p style="font-size: 0.8rem; color: #999;">Reference: URL should be /preview/PROJECT_ID</p>
                    </body>
                </html>
            `
        };
    }

    if (!initAdmin() || !db) {
        return { statusCode: 500, body: "Database unavailable" };
    }

    try {
        const docSnap = await db.collection('generated_websites').doc(id).get();

        if (!docSnap.exists) {
            return {
                statusCode: 404,
                headers: { "Content-Type": "text/html" },
                body: `
                    <html>
                        <body style="font-family: sans-serif; text-align: center; padding: 50px; color: #666;">
                            <h1>404: Preview Not Found</h1>
                            <p>The requested AI-generated website (ID: ${id}) does not exist or has expired.</p>
                            <a href="https://codez48.netlify.app" style="color: #2563EB;">Return to Codez48</a>
                        </body>
                    </html>
                `
            };
        }

        const data = docSnap.data();

        return {
            statusCode: 200,
            headers: {
                "Content-Type": "text/html",
                "Access-Control-Allow-Origin": "*",
                "Content-Security-Policy": "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:;"
            },
            body: data.html
        };

    } catch (error) {
        console.error("Preview Retrieval Error:", error.message);
        return {
            statusCode: 500,
            headers: { "Content-Type": "text/plain" },
            body: "Internal Server Error: " + error.message + "\nStack: " + error.stack
        };
    }
};
