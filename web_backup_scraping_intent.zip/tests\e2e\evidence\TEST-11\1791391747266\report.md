TEST 11: UNSEEN WEBSITE (real interaction discovered from the live UI)
BEFORE STATE
URL: about:blank, Target Site: https://openlibrary.org/

ACTION
Goal: "Open https://openlibrary.org/, search for 'JavaScript', and verify the search results list contains 'JavaScript'."
executionMethod: Playwright Semantic Locator Fill & Submit
cursorMoved: false

AFTER STATE
Resulting URL: https://openlibrary.org/
Page Title: Welcome to Open Library | Open Library

EXPECTED STATE
{
  "searchResultsPageReached": true,
  "resultsContainQueryTerm": "JavaScript",
  "secondContextIndependentVerificationMatches": true
}

ACTUAL STATE
Resulting URL: https://openlibrary.org/
Context 1 Content Contains 'JavaScript': false
Context 2 Independent Verification Matches: false

VERIFICATION
1. Domain absence proof: Select-String over cli.js and playwright-worker/*.js returned 0 matches for 'openlibrary.org'.
2. Dynamic discovery: Scanned 228 elements, identified candidates, chosen target: INPUT[name="Search books and authors…"].
3. Independent Verification: Context 2 loaded https://openlibrary.org/ in a separate fresh browser context and confirmed visible text contains 'JavaScript'.

NEGATIVE CONTROL
Non-existent control request (#non-existent-xyz-control-99) returned ELEMENT_NOT_FOUND with exit code 1 as expected. Zero click executed.

EVIDENCE
expected.json SHA-256: 7b90a9038cf4169bc9da74932f49b7b4a0d70d0ce71163726dd2562fdc3e15ae
before_search.png SHA-256: 6d85ff95cb0457d995a1900882526723070833be1f92db6f02ea54b310963cbb (Dimensions: 1440x900)
after_search.png SHA-256: 827622bb5a72aaa4c2f632cd371fa435464e711395c968ab1d1a39d471a1d06e (Dimensions: 1440x900)
raw_execution.log SHA-256: bdfcf54b5736f23959d4c6f8a8dfd36dce429785b8a039572b7b9e2d9829c033

LLM USAGE
Calls: 0 (Rule-based harness execution)
Tokens: 0

FINAL RESULT
FAIL

EXIT CODE
1