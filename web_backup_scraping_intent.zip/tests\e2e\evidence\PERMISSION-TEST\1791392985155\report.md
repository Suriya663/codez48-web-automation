REAL CLI PERMISSION-FLOW TEST REPORT

PROMPT SHOWN: "Grant permission for 'NATIVE_APPLICATION_CONTROL'?"
USER DECISION: Run A = Allow (yes), Run B = Deny (no)
PERMISSION MODE: FRESH_PROMPT (Run A: GRANTED, Run B: DENIED)
CAPABILITY: NATIVE_APPLICATION_CONTROL
APPLICATION: Notepad.exe
ACTION: Open Notepad after permission prompt evaluation
AFTER STATE: Run A: Notepad active with PID 1960. Run B: Zero process launched.
INDEPENDENT VERIFICATION:
1. Run A: Verified Notepad PID 1960 launched and active after Allow decision.
2. Run B: Verified zero Notepad process launched after Deny decision (pidB = "").
3. Permission store correctly distinguishes FRESH, DENIED, and CACHED modes without auto-approval.

FINAL RESULT
PASS

EXIT CODE
0