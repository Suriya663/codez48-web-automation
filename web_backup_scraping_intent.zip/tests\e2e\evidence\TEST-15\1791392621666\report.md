TEST 15: METATRADER 5 DEMO TRADE (5-GATE SAFETY PROTOCOL)
BEFORE STATE
MetaTrader 5 Binary: Installed (C:\Program Files\MetaTrader 5\terminal64.exe)
Process PID: 1216
Account Authorization State: UNAUTHORIZED / NO ACCOUNT LOGGED IN

ACTION
Launched MetaTrader 5 desktop application, foregrounded window, and evaluated Python MetaTrader5 API account_info().

AFTER STATE
Python MT5 API returned: INIT:False | ERR:(-6, 'Terminal: Authorization failed') | LOGIN:NONE | MODE:-1

EXPECTED STATE
{
  "gate1InstallationVerified": true,
  "gate2UIWindowForegrounded": true,
  "gate3IndependentAccountAuthorizationCheck": "Trade mode must be DEMO",
  "gate4SymbolAndVolumeDiscovered": "Valid tradable symbol with volume_min",
  "gate5HumanTerminalConfirmationRequired": "Phrase 'CONFIRM DEMO TRADE' required",
  "orderExecutedAndVerified": true
}

ACTUAL STATE
Process PID: 1216
Authorization Result: Terminal Authorization Failed (Error -6)
Account Environment: UNAUTHORIZED / NO DEMO ACCOUNT LOGGED IN

VERIFICATION
1. Gate 1 Passed: MetaTrader 5 binary verified at C:\Program Files\MetaTrader 5\terminal64.exe.
2. Gate 2 Passed: Application launched and process PID 1216 foregrounded.
3. Gate 3 Halted (NEEDS HUMAN): Independent Python MetaTrader5 API returned '(-6, Terminal: Authorization failed)'. No trading account is currently logged in.

NEGATIVE CONTROL
Safety gate halted execution before order preparation or submission. Zero trade placed.

EVIDENCE
expected.json SHA-256: 83bcb1c9cf1691b926389e422d0a39e155798c0df7698cd1d5d359b6b33b88d6
raw_execution.log SHA-256: 0e68b7fc376ef0210974db6821de8b47d4a44f23c6dc3cf074085cf81b2e556a

LLM USAGE
Calls: 0 (Rule-based harness execution)
Tokens: 0

FINAL RESULT
NEEDS HUMAN: Please log in to a DEMO/PAPER account manually in the MetaTrader 5 desktop application.

EXIT CODE
2