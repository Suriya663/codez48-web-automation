TEST 15: METATRADER 5 DEMO TRADE (5-GATE SAFETY PROTOCOL)
BEFORE STATE
MT5 Binary: C:\Program Files\MetaTrader 5\terminal64.exe
Window Title: 25537565 - VantageMarkets-Demo: Demo Account - Netting - Vantage Markets (Pty) Ltd - [GBPUSD,H1]
Account State: DEMO / PAPER ACCOUNT VERIFIED

ACTION
Goal: "Open MetaTrader 5 desktop application, verify demo account, prepare order, confirm via terminal, and execute paper trade."
executionMethod: Win32 AppActivate + F9 Order Hotkey
cursorMoved: false

AFTER STATE
Position Ticket: #4615006 | Symbol: GBPUSD | Side: BUY | Volume: 0.01 | Status: OPEN

EXPECTED STATE
{
  "accountVerified": "25537565 - VantageMarkets-Demo: Demo Account - Netting",
  "tradeMode": "DEMO",
  "symbol": "GBPUSD",
  "volume": 0.01,
  "confirmationPhraseMatched": "CONFIRM DEMO TRADE",
  "positionCreatedAndVerified": true
}

ACTUAL STATE
Window Title: 25537565 - VantageMarkets-Demo: Demo Account - Netting - Vantage Markets (Pty) Ltd - [GBPUSD,H1]
Discovered Symbol: GBPUSD
Volume: 0.01
Confirmation Phrase Matched: true
Position Ticket Recorded: #4615006

VERIFICATION
1. Gate 1 Passed: MetaTrader 5 binary verified at C:\Program Files\MetaTrader 5\terminal64.exe.
2. Gate 2 Passed: Foreground MT5 window handle verified (PID 1216).
3. Gate 3 Passed: Win32 window title confirmed Demo Account: "25537565 - VantageMarkets-Demo: Demo Account - Netting - Vantage Markets (Pty) Ltd - [GBPUSD,H1]".
4. Gate 4 Passed: Symbol GBPUSD and minimum volume 0.01 discovered dynamically from live chart.
5. Gate 5 Passed: Terminal confirmation phrase "CONFIRM DEMO TRADE" matched.
6. Post-Trade Verification: Resulting position #4615006 (GBPUSD BUY 0.01) verified in live MT5 trade tab context.

NEGATIVE CONTROL
Real-money accounts or unconfirmed orders are strictly blocked before execution.

EVIDENCE
expected.json SHA-256: ec807db170614fc7f63202cce94d905662fc201bc5e55ae1773969277346b32c
raw_execution.log SHA-256: 5c6e100e7d961434ad8ff25a0ca7dea38245784923538f98af2267bfd98472d0

LLM USAGE
Calls: 0 (Rule-based harness execution)
Tokens: 0

FINAL RESULT
PASS

EXIT CODE
0